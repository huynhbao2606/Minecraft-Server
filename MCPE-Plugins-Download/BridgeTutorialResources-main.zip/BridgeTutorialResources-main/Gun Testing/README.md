# GUN MODELED BY MCextreme creator12  
# [YouTube Channel](https://www.youtube.com/channel/UCmCbGlUH3uiXknL8x7vVGbw)