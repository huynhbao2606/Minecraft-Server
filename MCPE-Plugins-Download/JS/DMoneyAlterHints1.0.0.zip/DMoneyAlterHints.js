//LiteLoaderScript Dev Helper
/// <reference path="C:\LLse/JS/Api.js" /> 


//注册插件
ll.registerPlugin(`DMoneyAlterHints`,`经济变更提示`,[1,0,0],{"作者":"DZDGame工作室","发布网站":"www.minebbs.com"})
//配置文件
var conf=new JsonConfigFile(`.\\plugins\\DMoneyAlterHints\\data.json`)
//注册监听
mc.listen("onMoneyReduce",(xuid,m)=>{
    if(!conf.get(xuid).js){return}
    let pl=mc.getPlayer(xuid)
    //校验pl是否合法
    if(pl==null){return}
    pl.tell(`[提示]您的账户余额减少了${m}元,当前余额:${money.get(xuid)}`)
    mc.runcmdEx(`playsound note.harp "${pl.name}" ${pl.blockPos.x} ${pl.blockPos.y} ${pl.blockPos.z} 1 2`)
    setTimeout(()=>{mc.runcmdEx(`playsound note.harp "${pl.name}" ${pl.blockPos.x} ${pl.blockPos.y} ${pl.blockPos.z} 1 1`)},300)
})
mc.listen("onMoneyAdd",(xuid,m)=>{
    if(!conf.get(xuid).zj){return}
    let pl=mc.getPlayer(xuid)
    //校验pl是否合法
    if(pl==null){return}
    pl.tell(`[提示]您的账户余额增加了${m}元,当前余额:${money.get(xuid)}`)
    mc.runcmdEx(`playsound note.harp "${pl.name}" ${pl.blockPos.x} ${pl.blockPos.y} ${pl.blockPos.z} 1 2`)
    setTimeout(()=>{mc.runcmdEx(`playsound note.harp "${pl.name}" ${pl.blockPos.x} ${pl.blockPos.y} ${pl.blockPos.z} 1 1`)},300)
})
mc.listen("onMoneyTrans",(xuid,to,m)=>{
    if(!conf.get(xuid).zz){return}
    let pl=mc.getPlayer(xuid)
    let pt=mc.getPlayer(to)
    //校验pl是否合法
    if(pl==null){return}
    //校验pt是否合法
    if(pt==null){return}
    if(pt==null){
        pl.tell(`[提示]您给${data.xuid2name(to)}转账了${m}元,当前余额:${money.get(xuid)}`)
        mc.runcmdEx(`playsound note.harp "${pl.name}" ${pl.blockPos.x} ${pl.blockPos.y} ${pl.blockPos.z} 1 2`)
        setTimeout(()=>{mc.runcmdEx(`playsound note.harp "${pl.name}" ${pl.blockPos.x} ${pl.blockPos.y} ${pl.blockPos.z} 1 1`)},300)
    }
    else{
        pl.tell(`[提示]您给${pt.name}转账了${m}元,当前余额:${money.get(xuid)}`)
        pt.tell(`[提示]${pt.name}给您转账了${m}元,当前余额:${money.get(xuid)}`)
        mc.runcmdEx(`playsound note.harp "${pl.name}" ${pl.blockPos.x} ${pl.blockPos.y} ${pl.blockPos.z} 1 2`)
        setTimeout(()=>{mc.runcmdEx(`playsound note.harp "${pl.name}" ${pl.blockPos.x} ${pl.blockPos.y} ${pl.blockPos.z} 1 1`)},300)
    }
})
mc.listen("onMoneySet",(xuid,m)=>{
    if(!conf.get(xuid).sz){return}
    let pl=mc.getPlayer(xuid)
    //校验pl是否合法
    if(pl==null){return}
    pl.tell(`[提示]您的账户余额被设置成${m}元!`)
    mc.runcmdEx(`playsound note.harp "${pl.name}" ${pl.blockPos.x} ${pl.blockPos.y} ${pl.blockPos.z} 1 2`)
    setTimeout(()=>{mc.runcmdEx(`playsound note.harp "${pl.name}" ${pl.blockPos.x} ${pl.blockPos.y} ${pl.blockPos.z} 1 1`)},300)
})
//注册命令
mc.regPlayerCmd("dmah","经济变更提示偏好设置",(pl)=>{
    let ph=conf.get(pl.xuid)
    let fm=mc.newCustomForm()
    fm.setTitle(`偏好设置`)
    fm.addSwitch(`余额减少提示`,ph.js)
    fm.addSwitch(`余额增加提示`,ph.zj)
    fm.addSwitch(`转账提示`,ph.zz)
    fm.addSwitch(`余余额被设置提示`,ph.sz)
    pl.sendForm(fm,(pl,id)=>{
        if(id!=null){
            let ls={}
                ls["js"]=id[0]
                ls["zj"]=id[1]
                ls["zz"]=id[2]
                ls["sz"]=id[3]
            conf.set(pl.xuid,ls)
        }
    })
})
//监听玩家进服
mc.listen("onPreJoin",(pl)=>{
    if(conf.get(pl.xuid)==null){
        let ls={}
            ls["js"]=true
            ls["zj"]=true
            ls["zz"]=true
            ls["sz"]=true
        conf.init(pl.xuid,ls)
    }
})
//打印信息
log(`DMoneyAlterHints加载完成,输入命令 /ll plugins DMoneyAlterHints 查看具体信息`)