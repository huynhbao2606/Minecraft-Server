# EntityCounter

看看服务器内的生物统计信息！

## 介绍

![1](readme/Screenshot_20221124-215235.png)

## 指令

### `entc [showAnalytics:boolean] [targets:target]`

- `showAnalytics` - _可选_，是否显示详细生物统计信息
- `targets` - _可选_，如果填了此项，统计信息将只包含该目标选择器所选择的生物

## 配置文件

插件没有配置文件

## 联系我

QQ：3076823485  
吹水群：[1105946125](https://jq.qq.com/?_wv=1027&k=Z3n1MpEp)  
邮箱：<lgc2333@126.com>

## 赞助

感谢大家的赞助！你们的赞助将是我继续创作的动力！

- [爱发电](https://afdian.net/@lgc2333)
- <details>
    <summary>赞助二维码（点击展开）</summary>

  ![讨饭](https://raw.githubusercontent.com/lgc2333/ShigureBotMenu/master/src/imgs/sponsor.png)

  </details>

## 更新日志

暂无
