# OneBotBridge

## 安装 & 使用

本插件与 LLSEKoishi 同步发布，已经一起打包在了 LLSEKoishi 发布的压缩包里，安装 LLSEKoishi 即可使用

在使用本插件前，请先按照 [这里](../../res/koishi.yml) 修改一下插件的配置项，然后重启服务器

呃呃 我不会写文档 所以有什么问题加群问我吧 群号在 LLSEKoishi 文档里

## 效果图

![1](readme/QQ%E6%88%AA%E5%9B%BE20221212200412.png)  
![2](readme/QQ%E6%88%AA%E5%9B%BE20221212200840.png)  
![3](readme/Screenshot_20221212-200737.png)

## 更新日志

暂无
