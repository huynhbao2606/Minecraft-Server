# SimpleTransferCmd

简易跨服指令

## 指令

### `transfer <host: string> <port: integer> [player: Player]`

- 权限：所有人
- 参数：
  - `host` 服务器 IP
  - `port` 服务器端口
  - `player` 指定跨服玩家，仅 OP、控制台和命令方块 可用该参数
