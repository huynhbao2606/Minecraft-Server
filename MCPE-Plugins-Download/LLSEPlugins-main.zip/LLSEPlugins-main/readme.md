# LLSEPlugins

[![wakatime](https://wakatime.com/badge/user/b61b0f9a-f40b-4c82-bc51-0a75c67bfccf/project/d13550ef-4897-4e11-a57c-f45b2c6511e4.svg)](https://wakatime.com/badge/user/b61b0f9a-f40b-4c82-bc51-0a75c67bfccf/project/d13550ef-4897-4e11-a57c-f45b2c6511e4)
[![CodeFactor](https://www.codefactor.io/repository/github/lgc2333/llseplugins/badge)](https://www.codefactor.io/repository/github/lgc2333/llseplugins)

Author: [student_2333](https://github.com/lgc2333)

License: Apache-2.0

[插件下载安装教程](tutorial.md)

## Description

Plugins for LiteLoader-ScriptEngine
