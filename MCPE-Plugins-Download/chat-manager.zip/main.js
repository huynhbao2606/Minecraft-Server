const chat = require('./chat.js');
const prefix = require('./prefixes.js');
const bot = require('./bot.js')
const config = require('./config.js');

ll.registerPlugin(
	/* name */ "Chat manager",
	/* introduction */ "port of java chat manager plugin",
	/* version */ [1, 0, 0],
	/* otherInformation */ {}
);

